def do():
    return (u'Latest Test for Navid!')