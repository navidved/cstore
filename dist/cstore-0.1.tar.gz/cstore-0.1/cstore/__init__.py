def do():
    return (u'just a test for Navid!')